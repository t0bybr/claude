---
name: crawl4ai
description: "Web crawling and content extraction to clean markdown files. Use this skill when the user wants to: (1) Crawl a website or webpage, (2) Extract and clean content from URLs, (3) Create markdown documentation from websites, (4) Analyze website structure before crawling, (5) Download website content including subpages. Typical triggers include 'crawl this website', 'extract content from URL', 'download this site as markdown', 'analyze website structure'."
---

# Crawl4AI - Website Crawling & Content Extraction

## Overview

This skill enables crawling websites and extracting clean, structured content into markdown files with proper metadata. It uses an intelligent **3-stage approach** to identify and extract only the main content while removing navigation, headers, footers, and other non-essential elements.

### Three-Stage Smart Crawling

1. **HTML-Analyse (Stage 1):** Downloads the page and intelligently identifies the main content area using semantic HTML tags, content IDs/classes, and text-to-link ratio analysis
2. **Inhalts-Extraktion (Stage 2):** Extracts only the identified main content using CSS selectors, excluding navigation and headers
3. **Nachbearbeitung (Stage 3):** Post-processes the markdown to remove pagination, duplicate sections, and navigation remnants

This results in **clean, focused content** with up to 94% reduction in token count compared to naive extraction.

## Workflow Decision Tree

**When the user provides a URL:**

1. **Start with smart crawling:**
   → Use `crawl_to_markdown.py` which automatically:
   - Analyzes the HTML structure
   - Identifies the main content area
   - Extracts only relevant content
   - Removes navigation, headers, footers
   - Cleans pagination and duplicates

2. **After crawling:**
   - Check output directory for clean markdown results
   - Review frontmatter for metadata (tokens, language, keywords)
   - Content will be focused on main text with minimal noise

**Note:** The old multi-page recursive crawling has been replaced with single-page smart extraction for better quality and focused results.

## Crawling Process

### Smart Crawl to Markdown

Main crawling script that intelligently extracts clean content and creates markdown files:

```bash
python scripts/crawl_to_markdown.py <url> [options]
```

**Parameters:**
- `<url>`: URL to crawl (required)
- `--output-dir PATH`: Output directory (default: ./crawled_site)
- `--wait-time N`: JavaScript wait time in seconds (default: 5.0)
- `--single-page`: Compatibility flag (currently always single-page mode)

**What it does - Three-Stage Process:**

**Stage 1: HTML-Analyse**
- Downloads the complete HTML of the page
- Identifies main content area using:
  - Semantic HTML5 tags (`<main>`, `<article>`)
  - Common content IDs/classes (content, main, article, inhalt)
  - Text-to-link ratio scoring (prefers text-heavy elements)
- Identifies elements to exclude (nav, header, footer, menus)

**Stage 2: Inhalts-Extraktion**
- Re-crawls the page using identified CSS selectors
- Uses crawl4ai's `css_selector` and `excluded_selector` features
- Extracts only the main content area
- Generates clean markdown from the selected content

**Stage 3: Nachbearbeitung**
- Removes pagination links (1|2|3, Weiter, Zurück)
- Filters out navigation remnants
- Detects and removes duplicate sections
- Cleans excessive whitespace
- Generates frontmatter with:
  - Auto-generated description from content
  - Extracted keywords
  - Token estimate
  - Language detection
  - Content hash for change detection

**Examples:**

Basic page extraction:
```bash
python scripts/crawl_to_markdown.py https://example.com/about
```

Custom output directory:
```bash
python scripts/crawl_to_markdown.py https://example.com --output-dir ./my_content
```

Longer JavaScript wait time (for heavy dynamic sites):
```bash
python scripts/crawl_to_markdown.py https://example.com --wait-time 10.0
```

**Output Quality:**
- Typical token reduction: 85-95% compared to naive extraction
- Only main content preserved
- Clean, readable markdown
- No navigation clutter

## Frontmatter Metadata

Each markdown file includes comprehensive YAML frontmatter:

```yaml
---
crawled_at: 2024-11-04T15:30:00.123456  # ISO timestamp
url: https://example.com/page            # Exact URL crawled
title: "Page Title"                      # Extracted page title
has_subpages: true                       # Whether page has child pages
content_hash: abc123...                  # SHA256 hash for change detection
language: de                             # Detected language (de/en)
estimated_tokens: 1250                   # Rough token count
has_external_embeds: false               # YouTube, iframes, etc.
description: "Short SEO description"     # Meta description if available
keywords:                                # Top 10 extracted keywords
  - documentation
  - tutorial
  - beispiel
image_count: 5                           # Number of images found
pdf_count: 2                             # Number of PDFs linked
---
```

## Content Cleaning

The script automatically removes:
- Navigation menus (main nav, submenu controls)
- Page headers and footers
- Pagination controls (1|2|3, Weiter, Zurück, etc.)
- Slider/carousel controls
- Duplicate sections
- Empty sections and excessive whitespace
- Menu/navigation links

It preserves:
- Main content text and headings
- Content links relevant to the topic
- Images within the main content
- Structured data (lists, tables where present)
- Proper markdown formatting

## Output Structure

The crawler creates a simple, focused output:

```
crawled_site/
└── index.md              # Extracted main content with frontmatter
```

**index.md** contains:
- Complete YAML frontmatter with metadata
- Clean, focused main content
- No navigation or clutter
- Auto-generated description and keywords

## Usage Workflow

### Basic Usage:
```bash
# Simply provide the URL
python scripts/crawl_to_markdown.py https://example.com
```

The script automatically:
1. Analyzes the page structure
2. Identifies main content
3. Extracts and cleans it
4. Saves to `crawled_site/index.md`

### Custom Output:
```bash
# Specify output directory
python scripts/crawl_to_markdown.py https://example.com --output-dir ./my_content
```

### Dynamic Sites:
```bash
# Increase wait time for JavaScript-heavy sites
python scripts/crawl_to_markdown.py https://example.com --wait-time 10.0
```

## KI-gestützte Metadaten (Optional)

Der Skill kann **Claude Haiku** nutzen, um intelligente Descriptions und Keywords zu generieren.

### Mit KI (Empfohlen):
```bash
export ANTHROPIC_API_KEY=sk-ant-...
```

**Vorteile:**
- Intelligente, kontextbezogene Descriptions
- Semantisch sinnvolle Keywords mit korrekter Großschreibung
- Versteht den Inhalt und fasst ihn zusammen

**Kosten:** ~0.2 Cent pro Seite (Claude Haiku)

### Ohne KI (Fallback):
Wenn kein API-Key gesetzt ist, nutzt der Skill automatisch heuristische Methoden:
- Extrahiert erste substantielle Textzeile als Description
- Ermittelt Keywords nach Häufigkeit
- Funktioniert gut, aber weniger präzise

**Der Skill zeigt beim Start an, welcher Modus verwendet wird:**
- `✨ KI-Metadaten-Generierung aktiviert (Claude Haiku)` - KI wird genutzt
- `ℹ️  KI-Metadaten-Generierung nicht verfügbar` - Fallback-Methoden werden genutzt

## Installation Requirements

The crawl4ai library must be installed in a virtual environment. If the venv doesn't exist yet, create and install:

```bash
# Navigate to skill directory
cd /Users/tobiasbrummer/.claude/skills/crawl4ai

# Create virtual environment (if not exists)
python3 -m venv venv

# Activate and install crawl4ai
source venv/bin/activate
pip install crawl4ai

# Install anthropic for KI-based metadata generation (optional but recommended)
pip install anthropic

# Install playwright browsers (one-time setup)
playwright install chromium
```

**Important:** All scripts must be run using the venv's Python interpreter:
```bash
/Users/tobiasbrummer/.claude/skills/crawl4ai/venv/bin/python3 scripts/crawl_to_markdown.py <url>
```

See `references/crawl4ai_reference.md` for detailed API documentation.

## Common Issues and Solutions

**Issue: Pages taking too long**
- Reduce `--wait-time` if site doesn't need much JavaScript
- Increase `--wait-time` if content is missing (up to 10s for heavy JS sites)

**Issue: Wrong content extracted**
- The script uses intelligent heuristics to find main content
- If it picks the wrong element, the site may have unusual structure
- Check the console output to see what selector was used

**Issue: Missing content**
- Some sites may need longer `--wait-time` for JavaScript
- Try increasing from 5s to 8-10s for dynamic content
- Check if site requires authentication (not supported)

**Issue: Still seeing some navigation**
- The 3-stage cleaning is aggressive but may miss some edge cases
- The script will continuously improve pattern matching
- Most navigation is successfully removed (85-95% reduction typical)

## Tips for Best Results

1. **Default settings work well** for most sites
2. **Check token estimate** in output to verify content size
3. **Content hash in frontmatter** allows easy change detection for re-crawls
4. **Review the extracted content** to ensure quality
5. **Adjust wait-time** for JavaScript-heavy sites
6. **Use descriptive output directories** when crawling multiple pages
